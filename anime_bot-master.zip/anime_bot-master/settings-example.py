token = 'your_token'
confirmation_token = 'your_conf_toket'
service_key = 'your_service_key'
